from datetime import datetime

time = datetime.now()

print(time)